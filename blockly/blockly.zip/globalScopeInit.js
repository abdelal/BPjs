/* global package imports, variables, etc. */

// /!\ Currently deactivated, as we have nothing to add here yet. Re-activate in BProgram's setup() method.

//importPackage(Packages.bp);
//importPackage(Packages.bp.eventsets);

//importPackage(Packages.bp.exceptions);
//java.lang.System.out.println("evaluated globalScopeInit");
